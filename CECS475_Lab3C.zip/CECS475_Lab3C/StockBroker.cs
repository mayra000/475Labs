﻿using System;
using System.Collections.Generic; //threading
using System.IO; //writing to a file
using System.Text; //for StringBuilder
using System.Threading;
using System.Threading.Tasks;
using System.Linq;

namespace CECS475_Lab3C
{
    class StockBroker
    {
        //private static Mutex mutex = new Mutex();
        string brokerName;
        public static List<Stock> stocks = new List<Stock>();
        public static bool newFile = true;
        public StockBroker(string brokerName)
        {
            this.brokerName = brokerName;
        }

        public StockBroker(string brokerName, List<Stock> stocksList)
        {
            this.brokerName = brokerName;
            stocks = stocksList;
        }

        //Subscribe to the event
        public void AddStock(Stock stock)
        {
            stocks.Add(stock);
            stock.StockEvent += Notify;
        }

        ////Event Handler: To respond to an event, you define an event handler method in the event receiver.
        //public void Notify(object sender, EventData e)
        //{
        //    string header = "Broker".PadRight(15) + "Stock".PadRight(15) + "Value".PadRight(15) + "Changes".PadRight(15) + "Time";
        //    string path = @"C:\Users\nguye\source\repos\CECS424_Lab3\StocksOutput.txt";
        //    DateTime time = DateTime.Now;
        //    string contents = brokerName.PadRight(15) + e.Name.PadRight(15) + e.CurrentValue.ToString().PadRight(15) + e.NumOfChanges.ToString().PadRight(15) + time.ToString().PadRight(15);
        //    //blocks the current thread until the current WaitHandle receives the signal
        //    mutex.WaitOne();
        //    //if it's a new file, create it
        //    if (newFile == true)
        //    {
        //        File.Create(path).Close();
        //    }
        //    //append everything inside to the file
        //    using (StreamWriter sw = File.AppendText(path))
        //    {
        //        if (newFile == true)
        //        {
        //            Console.WriteLine(header);
        //            sw.WriteLine(header);
        //            newFile = false;
        //        }
        //        Console.WriteLine(contents);
        //        sw.WriteLine(contents);
        //        sw.Close();
        //    }
        //    //releases the mutex once
        //    mutex.ReleaseMutex();
        //}

        public async void Notify(object sender, EventData e)
        {
            string path = @"C:\Users\Sanchez\Desktop\CECS475_Lab3C\StocksOutput.txt";
            DateTime time = DateTime.Now;
            string contents = (brokerName.PadRight(15) + e.Name.PadRight(15) + e.CurrentValue.ToString().PadRight(15) + e.NumOfChanges.ToString().PadRight(15) + time.ToString().PadRight(15));
            await WriteTextAsync(path, contents);
        }

        private async Task WriteTextAsync(string filepath, string text)
        {
            string newLine = "\n";
            string header = "Broker".PadRight(15) + "Stock".PadRight(15) + "Value".PadRight(15) + "Changes".PadRight(15) + "Time";

            //if it's a new file, create it
            if (newFile == true)
            {
                File.Create(filepath).Close();
            }
            //append everything inside to the file
            using (FileStream fs = new FileStream(filepath,
                        FileMode.Append, FileAccess.Write, FileShare.ReadWrite,
                        bufferSize: 4096, useAsync: true))
            {
                using (StreamWriter sw = new StreamWriter(fs))
                {
                    if (newFile == true)
                    {
                        Console.Out.WriteLine(header);
                        sw.WriteLine(header);
                        newFile = false;
                        sw.Flush();
                    }
                    await Console.Out.WriteLineAsync(text);
                    await sw.WriteAsync(text);
                    await sw.WriteAsync(newLine);
                    sw.Flush();
                }
                fs.Dispose();
            }

        }

    }
}
