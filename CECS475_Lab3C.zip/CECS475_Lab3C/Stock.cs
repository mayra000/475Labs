﻿/*
 * Mayra Sanchez
 * CECS 475
 * Phuong Nguyen
 * Lab 3 - Stock
 */

using System;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;


namespace CECS475_Lab3C
{
    public class EventData : EventArgs
    {
        public EventData(string name, int currentValue, int numOfChanges)
        {
            Name = name;
            CurrentValue = currentValue;
            NumOfChanges = numOfChanges;
        }
        public string Name { get; set; }
        public int CurrentValue { get; set; }
        public int NumOfChanges { get; set; }

    }
    class Stock
    {
        readonly string name;
        private int currentValue;
        readonly private int initialValue, notificationThreshold, maxChange;
        public int numOfChanges = 0;

        //Event: An event is a message sent by an object to signal the occurrence of an action. 
        //The action can be caused by user interaction, such as a button click, or it can result from some other program logic, such as changing a property’s value.
        protected virtual void onStockEvent(string name, int currentValue, int numOfChanges)
        {
            StockEvent?.Invoke(this, new EventData(name, currentValue, numOfChanges));
        }
        //EventHandler<TEventArgs> Delegate 
        public event EventHandler<EventData> StockEvent;

        public Stock(string name, int startingValue, int maxChange, int threshold)
        {
            this.name = name;
            initialValue = startingValue;
            currentValue = initialValue;
            this.maxChange = maxChange;
            notificationThreshold = threshold;
            //create a new thread
            Thread thread = new Thread(new ThreadStart(Activate));
            //change thread state to running
            thread.Start();
        }

        public void Activate()
        {
            for (; ; )
            {
                Thread.Sleep(500); // 1/2 second
                ChangeStockValue();
            }
        }

        public void ChangeStockValue()
        {
            Random r = new Random();
            currentValue += r.Next(1, maxChange);
            numOfChanges++;
            if ((currentValue - initialValue) > notificationThreshold)
            {
                onStockEvent(name, currentValue, numOfChanges);
            }

        }
    }

    //working on the raise and the event handler
    //event data class being worked on in order to take in info that are specific to the event being raised
    public class StockNotifEventArgs : EventArgs
    {
        private string sName;
        private int sCurrVal;
        private int sInitialVal;
        private int sDifference;
        private int numChanges;

        public StockNotifEventArgs(string name, int initialVal, int currentVal, int diff, int changes)
        {
            this.sName = name;
            this.sInitialVal = initialVal;
            this.sCurrVal = currentVal;
            this.sDifference = diff;
            this.numChanges = changes;

        }

        public string Name
        {
            get => sName;
            set => sName = value;
        }

        public int InitialValue
        {
            get => sInitialVal;
            set => sInitialVal = value;
        }

        public int CurrentVal
        {
            get => sCurrVal;
            set => sCurrVal = value;
        }

        public int Difference
        {
            get => sDifference;
            set => sDifference = value;
        }

        public int NumChanges
        {
            get => numChanges;
            set => numChanges = value;
        }

    }

    //declaring delegate for the event
    public delegate void StockNotifHandler(Object sender, StockNotifEventArgs e);
}
